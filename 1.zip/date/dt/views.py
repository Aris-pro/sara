from django.shortcuts import render
import datetime


def hours(request, offset):
    now = datetime.datetime.now()

    future_time = now + datetime.timedelta(hours=offset)

    before_time = now - datetime.timedelta(hours=offset)

    context = {
        'current_time': now,
        'offset': offset,
        'future_time': future_time,
        'before_time': before_time
    }

    return render(request, 'time.html', context)