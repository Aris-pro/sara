from django.apps import AppConfig


class LyttConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'lytt'
