from django.contrib import admin
from library_app.models import Book , Member
# Register your models here.
admin.site.register(Book)
admin.site.register(Member)