from django.db import models

class Book(models.Model):
    bookcode = models.CharField(max_length=10)
    bookname = models.CharField(max_length=100)
    author = models.CharField(max_length=50)

    def __str__(self):
        return f"{self.bookcode} - {self.bookname}"


class Member(models.Model):
    member_id = models.CharField(max_length=10)
    name = models.CharField(max_length=50)
    sem = models.IntegerField()
    borrowed_books = models.ManyToManyField(Book, related_name='members', blank=True)

    def __str__(self):
        return f"{self.member_id} - {self.name}"