from django.urls import path
from library_app.views import *

urlpatterns = [
    path('mainpage/', home, name='home'),
    path('memberlist/', memberlist, name='memberlist'),
    path('booklist/', booklist, name='booklist'),
    path('borrow/', borrowbook, name='borrowbook'),
    path('borrowedlist/', borrowedMembers, name='borrowedMembers'),
]