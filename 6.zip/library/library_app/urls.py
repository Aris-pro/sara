from django.urls import path
from library_app.views import *

urlpatterns = [
    path('mainpage/', home, name='home'),
    path('memberlist/', memberlist, name='memberlist'),
    path('booklist/', booklist, name='booklist'),
    path('borrow/', borrowbook, name='borrowbook'),
    path('borrowedlist/', borrowedMembers, name='borrowedMembers'),

    path('books/', BookListView.as_view(), name='book-list'),
    path('books/<int:pk>/', BookDetailView.as_view(), name='book-detail'),
    path('books/<int:pk>/delete/', BookDeleteView.as_view(), name='book-delete'),
]