from django.shortcuts import render, redirect
from django.views import generic
from django.urls import reverse_lazy

from library_app.models import Member, Book


# ---------------- HOME PAGE ----------------

def home(request):
    return render(request, 'homepage.html')


# ---------------- MEMBER LIST ----------------

def memberlist(request):
    members = Member.objects.all()

    return render(request, 'memberlist.html', {
        'member_list': members
    })


# ---------------- BOOK LIST WITH FILTERS ----------------

def booklist(request):
    books = Book.objects.all()

    author = request.GET.get('author')
    name = request.GET.get('name')

    if author:
        books = books.filter(author__icontains=author)

    if name:
        books = books.filter(bookname__icontains=name)

    return render(request, 'booklist.html', {
        'book_list': books
    })


# ---------------- BORROW BOOK ----------------

def borrowbook(request):

    if request.method == "POST":

        member_id = request.POST.get('member')
        book_id = request.POST.get('book')

        selected_member = Member.objects.get(id=member_id)
        selected_book = Book.objects.get(id=book_id)

        selected_member.borrowed_books.add(selected_book)

        return redirect('/borrowedlist/')

    members = Member.objects.all()
    books = Book.objects.all()

    return render(request, 'borrow.html', {
        'member_list': members,
        'book_list': books
    })


# ---------------- BORROWED MEMBERS ----------------

def borrowedMembers(request):

    book_list = Book.objects.all()

    member_list = None
    selected_book = None

    if request.method == "POST":

        book_id = request.POST.get('book')

        selected_book = Book.objects.get(id=book_id)

        member_list = selected_book.members.all()

    return render(request, 'borrowedlist.html', {
        'Book_List': book_list,
        'member_list': member_list,
        'book': selected_book
    })


# =========================================================
#                 GENERIC CLASS BASED VIEWS
# =========================================================


# ---------------- GENERIC BOOK LIST VIEW ----------------

class BookListView(generic.ListView):

    model = Book

    template_name = "GenericListViewBook.html"


# ---------------- GENERIC BOOK DETAIL VIEW ----------------

class BookDetailView(generic.DetailView):

    model = Book

    template_name = "GenericDetailedViewBook.html"

# ---------------- GENERIC BOOK DELETE VIEW ----------------

class BookDeleteView(generic.DeleteView):

    model = Book

    template_name = "GenericDeleteViewBook.html"

    success_url = reverse_lazy('book-list')