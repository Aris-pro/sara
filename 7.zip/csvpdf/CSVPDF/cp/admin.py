from django.contrib import admin
from cp.models import course1
# Register your models here.
admin.site.register(course1)
