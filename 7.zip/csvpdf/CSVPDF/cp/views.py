from django.shortcuts import render
from django.http import HttpResponse
from cp.models import course1
import csv

# View to display course list
def courselist2(request):
    courses = course1.objects.all()
    return render(request, 'course_list.html', {'course_list1': courses})


# CSV Generation View
def generateCSV(request):
    courses = course1.objects.all()

    # Create HTTP response with CSV content type
    resp = HttpResponse(content_type='text/csv')
    resp['Content-Disposition'] = 'attachment; filename="course_data.csv"'

    # Create CSV writer
    writer = csv.writer(resp)

    # Header row
    writer.writerow(['Course Code', 'Course Name', 'Course Credits'])

    # Data rows
    for c in courses:
        writer.writerow([c.coursecode, c.coursename, c.credits])

    return resp


# PDF Generation View
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table


def generatePDF(request):
    courses = course1.objects.all()

    # Create HTTP response with PDF content type
    resp = HttpResponse(content_type='application/pdf')
    resp['Content-Disposition'] = 'attachment; filename="course_data.pdf"'

    # Create PDF document
    pdf = SimpleDocTemplate(resp, pagesize=A4)

    # Table data with header
    table_data = [['Course Code', 'Course Name', 'Course Credits']]

    # Add course data rows
    for c in courses:
        table_data.append([c.coursecode, c.coursename, c.credits])

    # Create table
    table = Table(table_data)

    # Build PDF
    pdf.build([table])

    return resp