from django.urls import path
from .views import user_signup, UserSigninView, UserSignoutView, dashboard_view

urlpatterns = [

    path("signup/", user_signup, name="user_signup"),

    path("signin/", UserSigninView.as_view(), name="user_signin"),

    path("signout/", UserSignoutView.as_view(), name="user_signout"),

    path("dashboard/", dashboard_view, name="dashboard"),

]